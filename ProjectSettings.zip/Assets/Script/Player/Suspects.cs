using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Suspects : MonoBehaviour
{
    [SerializeField] GameObject SuspectsUI;
    [SerializeField] bool showUI;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {

                SuspectsUI.SetActive(!SuspectsUI.gameObject.activeSelf);


        }
        
    }
}
