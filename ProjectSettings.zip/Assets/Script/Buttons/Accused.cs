using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Accused : MonoBehaviour
{
    public int Suspect1;
    public int Suspect2;
    public int Suspect3;
    public int Suspect4;

    public void SuspectOne()
    {
        SceneManager.LoadSceneAsync(Suspect1);
    }
    public void SuspectTwo()
    {
        SceneManager.LoadSceneAsync(Suspect2);
    }
    public void SuspectThree()
    {
        SceneManager.LoadSceneAsync(Suspect3);
    }
    public void SuspectFour()
    {
        SceneManager.LoadSceneAsync(Suspect4);
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
