using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class JoelV2 : MonoBehaviour
{
    private Transform highlight;
    private Transform selection;
    private RaycastHit raycastHit;
    [SerializeField] GameObject JoelUI;


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X))
        {
            JoelUI.SetActive(false);

        }
        // Highlight
        if (highlight != null)
        {

            highlight = null;
        }
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (!EventSystem.current.IsPointerOverGameObject() && Physics.Raycast(ray, out raycastHit)) //Make sure you have EventSystem in the hierarchy before using EventSystem
        {
            highlight = raycastHit.transform;
            if (highlight.CompareTag("Joel") && highlight != selection)
            {
                Debug.Log("2");
            }
            else
            {
                highlight = null;
                //Debug.Log("3");
            }

        }

        // Selection
        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            if (highlight)
            {
                if (selection != null)
                {
                    //Debug.Log("4");
                }

                highlight = null;
            }
            else
            {
                if (selection)
                {
                    Debug.Log("6");
                    JoelUI.SetActive(!JoelUI.gameObject.activeSelf);
                    selection = null;
                }
            }
        }

    }


}
