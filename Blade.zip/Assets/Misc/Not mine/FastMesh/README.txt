These 3D models, all created with "Fast Mesh - 3D Asset Creation Tool", demonstrate the ease of creating 
Low Poly meshes. 

--------------------------------------------------------------------------------------------------------- 
Fast Mesh - 3D Asset Creation Tool
Specially created for Unity, "FastMesh" provides a fast and efficient tool for creating 3D models 
directly within the Unity editor.

https://assetstore.unity.com/packages/slug/288711

---------------------------------------------------------------------------------------------------------
███ YouTube ███

More detailed instructions on using FastMesh are available on our YouTube channel at https://www.youtube.com/@FastMesh