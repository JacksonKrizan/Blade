using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] GameObject ControlsUI;

    [SerializeField] GameObject IstructionsUI;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            ControlsUI.SetActive(!ControlsUI.gameObject.activeSelf);
        }
        if (Input.GetKeyDown(KeyCode.I))
        {
            IstructionsUI.SetActive(!IstructionsUI.gameObject.activeSelf);
        }
    }
}
